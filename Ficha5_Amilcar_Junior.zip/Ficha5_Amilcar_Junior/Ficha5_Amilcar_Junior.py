# (Nome completo, número, curso e ano letivo)
# (Amilcar da Rosa Pina , Júnior, 115809 , EIC , 3 ano)

import pyafai
import pyglet.window.mouse as mouse

class AgenteDeambulador(pyafai.Agent):
    def __init__(self):
        pyafai.Agent.__init__(self)

        # adiciona sensores - percepção
        sensorN = Sensor(bool,"S1"); self.add_perception(sensorN)
        sensorE = Sensor(bool,"S2"); self.add_perception(sensorE)
        sensorS = Sensor(bool,"S3"); self.add_perception(sensorS)
        sensorO = Sensor(bool,"S4"); self.add_perception(sensorO)

        # adiciona movimentos - acção
        movimentoN = Movimento("norte"); self.add_action(movimentoN)
        movimentoE = Movimento("este");  self.add_action(movimentoE)
        movimentoS = Movimento("sul");   self.add_action(movimentoS)
        movimentoO = Movimento("oeste"); self.add_action(movimentoO)

    def _think(self, delta):
        actions = []
        if (self._perceptions["S4"].value and not self._perceptions["S1"].value):
            actions = [self._actions['norte']]
        elif (self._perceptions["S1"].value and not self._perceptions["S2"].value):
            actions = [self._actions['este']]
        elif (self._perceptions["S2"].value and not self._perceptions["S3"].value):
            actions = [self._actions['sul']]
        elif (self._perceptions["S3"].value and not self._perceptions["S4"].value):
            actions = [self._actions['oeste']]
        else:
            pass
        return actions


class Sensor(pyafai.Perception):
    def update(self, agent):
        x = agent.body.x
        y = agent.body.y
        if self.name=='S1':
            self.value = (y == agent.world.grid_height-1) or not(agent.world.is_empty(x,y+1)) or not(agent.world.is_empty(x+1,y+1))
        elif self.name=='S2':
            self.value =  (x == agent.world.grid_width-1) or not(agent.world.is_empty(x+1,y)) or not(agent.world.is_empty(x+1,y-1))
        elif self.name=='S3':
            self.value = (y == 0) or not(agent.world.is_empty(x,y-1)) or not(agent.world.is_empty(x-1,y-1))
        elif self.name=='S4':
            self.value =  (x == 0) or not(agent.world.is_empty(x-1,y)) or not(agent.world.is_empty(x-1,y+1))

class Movimento(pyafai.Action):
    def execute(self, agent):
        if self.name == 'norte':
            agent.body.move_to(agent.body.x,agent.body.y+1)
        elif self.name == 'este':
            agent.body.move_to(agent.body.x+1,agent.body.y)
        elif self.name == 'sul':
            agent.body.move_to(agent.body.x,agent.body.y-1)
        elif self.name == 'oeste':
            agent.body.move_to(agent.body.x-1,agent.body.y)
        else:
            pass # não faz nada
def main():
    # inicia o display
    world = pyafai.World2DGrid(10, 10, 30, True, pyafai.World2DGrid.von_neumann,True,0.5)
    display = pyafai.Display(world)

    # cria o Agente
    obj = pyafai.Object(2, 1)
    shape = pyafai.shapes.Circle(10 , color=('c3B',(200,150,200)));     obj.add_shape(shape)
    shape = pyafai.shapes.Line(0,10,0,15, color=('c3B', (200,150,200))); obj.add_shape(shape)
    shape = pyafai.shapes.Line(10,0,15,0, color=('c3B', (200,150,200))); obj.add_shape(shape)
    shape = pyafai.shapes.Line(0,-10,0,-15, color=('c3B', (200,150,200))); obj.add_shape(shape)
    shape = pyafai.shapes.Line(-10,0,-15,0, color=('c3B', (200,150,200))); obj.add_shape(shape)
    shape = pyafai.shapes.Line(0,0,15,15, color=('c3B', (200,150,200))); obj.add_shape(shape)
    shape = pyafai.shapes.Line(10,-10,-15,15, color=('c3B', (200,150,200))); obj.add_shape(shape)
    shape = pyafai.shapes.Line(0,0,-15,-15, color=('c3B', (200,150,200))); obj.add_shape(shape)
    shape = pyafai.shapes.Line(10,-10,15,-15, color=('c3B', (200,150,200))); obj.add_shape(shape)
    agent = AgenteDeambulador()

    agent.body = obj
    world.add_agent(agent)

    # cria obstáculos
    shape_rect = []
    for i in range(6):
        shape_rect.append(pyafai.shapes.Rect(30,30, color=('c3B', (180, 180, 180))))

    obsctacle = pyafai.Object(9, 9); obsctacle.add_shape(shape_rect[0]); world.add_object(obsctacle)
    obsctacle = pyafai.Object(2, 2); obsctacle.add_shape(shape_rect[1]); world.add_object(obsctacle)
    obsctacle = pyafai.Object(3, 2); obsctacle.add_shape(shape_rect[2]); world.add_object(obsctacle)
    obsctacle = pyafai.Object(3, 3); obsctacle.add_shape(shape_rect[3]); world.add_object(obsctacle)
    obsctacle = pyafai.Object(3, 4); obsctacle.add_shape(shape_rect[4]); world.add_object(obsctacle)
    obsctacle = pyafai.Object(4, 4); obsctacle.add_shape(shape_rect[5]); world.add_object(obsctacle)
    '''
    obsctacle = pyafai.Object(5, 5); obsctacle.add_shape(shape_rect[6]); world.add_object(obsctacle)
    obsctacle = pyafai.Object(5, 4); obsctacle.add_shape(shape_rect[7]); world.add_object(obsctacle)
    obsctacle = pyafai.Object(4, 7); obsctacle.add_shape(shape_rect[8]); world.add_object(obsctacle)
    obsctacle = pyafai.Object(9, 8); obsctacle.add_shape(shape_rect[9]); world.add_object(obsctacle)
    '''
                   
    # entra no ciclo da aplicação    
    pyafai.run()

if __name__ == '__main__':
    main()